import express from 'express';

import { signupUser,loginUser,updateUser } from '../controller/user-controller.js';
import { createPost,updatePost,deletePost,getPost,getPosts } from '../controller/post-controller.js';
import { verifyToken } from '../utils/verify.js';
import { newComment,addComment,getComment } from '../controller/comment-controller.js';

const router=express.Router();
router.use(express.urlencoded({ extended: true }));
//post req ky body ate ha
router.post('/signup',signupUser);
router.post('/login',loginUser);
router.put("/:id",updateUser);
router.post('/create',verifyToken,createPost);
router.put("/post/:id",verifyToken,updatePost);
router.delete("/post/:id",verifyToken,deletePost);
router.get("/post/:id",verifyToken,getPost);
router.get("/post",verifyToken,getPosts);
router.post('/comment',verifyToken,newComment);
router.put('/comment/:id',verifyToken,addComment);
router.get("/comment/:id",verifyToken,getComment);


export default router;