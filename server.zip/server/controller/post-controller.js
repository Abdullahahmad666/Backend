import  Post from "../model/post.js"
export const createPost= async (request,response)=>{
    try{
        const post=await new Post(request.body);
        post.save();
        return response.status(200).json( "post saved successfully" );
    }catch(error){
        return response.status(200).json( error );
    }
}
export const updatePost = async (request, response) => {
    try {
        const upPost = await Post.findByIdAndUpdate(request.params.id, { $set: request.body }, { new: true });
        response.status(200).json(upPost)
    } catch (error) {
        console.error(error);
        return response.status(500).json({ msg: "error while updating post" });
    }
}
export const deletePost = async (request, response) => {
    try {
        await Post.findByIdAndDelete(request.params.id);
        response.status(200).json("post has been deleted");
    } catch (err) {
        console.error(error);
        return response.status(500).json({ msg: "error while deleting post" });
    }
}
export const getPost = async (request, response) => {
    try{ 
        const post=await Post.findById(request.params.id);
        response.status(200).json(post);
    }catch(err){
        console.error(error);
        return response.status(500).json({ msg: "error while reading a single post" });
    }
}
export const getPosts = async (request, response) => {
    try{ 
        const posts=await Post.find();
        response.status(200).json(posts);
    }catch(err){
        console.error(error);
        return response.status(500).json({ msg: "error while reading a all post" });
    }
}